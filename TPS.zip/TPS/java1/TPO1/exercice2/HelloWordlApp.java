public class HelloWordlApp{
    public static void main(string[] args){
    system.out.println("Hello wordl");
    }
}